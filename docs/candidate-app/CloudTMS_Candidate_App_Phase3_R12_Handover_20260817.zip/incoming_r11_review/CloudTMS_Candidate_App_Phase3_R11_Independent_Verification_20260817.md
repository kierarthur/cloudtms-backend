# CloudTMS Candidate App — Candidate Daily Phase 3 R11 independent source review

**Date:** 17 August 2026  
**Environment:** TEST preparation only  
**Disposition:** **NO-GO for the Phase 3 source installation/proving gate**

## 1. Executive verdict

R11 cannot be accepted for Google Apps Script installation or controlled enablement.

The controlling blocker is deliberately bounded to one complete operation family, as required by `01_INDEPENDENT_REVIEW_BRIEF.md`:

```text
Availability legacy write / CloudTMS mirror / lost-response recovery
```

Three defects inside that family are reproducible:

1. the rota-busy/deferred branch sends CloudTMS a command before the queued change has been durably written or revalidated by Google;
2. the normal mixed-result branch sends every requested date, including dates the legacy write rejected;
3. a non-terminal `409 ... / STATUS_CHECK` response is classified as a stable terminal failure, causing the durable operation to be deleted without the required status lookup.

These are not presentation issues. They can cause Google and CloudTMS to hold different availability facts, or can discard the only local identity needed to determine the outcome of an in-progress CloudTMS command.

Therefore:

```text
Do not paste, save, version, deploy or enable the R11 Apps Script source.
```

The earlier R10 Phase 2 / Phase 1B database verdict is not reversed. R10 remains the accepted dark backend boundary. This R11 finding concerns only the new Phase 3 Availability write adapter.

The correction authority in this report does **not** extend to Master Rota, projection, effects, Candidate core/Office, database functions, Worker routes, finance, Invoice, Banking Pay, Policy X or production. Those later R11 operation families are not certified by this NO-GO and must be re-audited after the bounded Availability correction.

---

## 2. Archive and provenance verification

Reviewed archive:

```text
CloudTMS_Candidate_App_Phase3_R11_Handover_20260817.zip
SHA-256: 19919b32e9e73a2330c315b51374dc3688d03c7e60ef995d4b3eaf2a28b8ffa0
Size: 1,683,772 bytes
```

Independent integrity result:

| Check | Result |
|---|---:|
| ZIP entries | 46 |
| ZIP corruption | none |
| Unsafe archive paths | 0 |
| Manifest payloads | 44 |
| SHA-256 manifest failures | 0 |
| Size-manifest entries | 44 |
| Pack validator | PASS |
| Local-path disclosures reported by validator | 0 |

Validator output:

```json
{"archive_entries":46,"decisions_pages":105,"local_path_disclosures":0,"manifest_payloads":44,"ok":true}
```

The package records source-only preparation: no live Google edit, Google deployment, Worker deployment, database mutation, feature activation or production action is claimed.

### Source identities

| Source | SHA-256 |
|---|---|
| Availability revised `Code.gs` | `4113dadcbd4044f222fafd51c78ff5bea8905cc22c8517107ba26866b269d905` |
| Availability helper | `4bc6cb8eaa77ef21ba98d90b52b0d05cc6363f9e41c800e430d95361869d85f9` |
| Availability rollback | `eacd187564ea9b0f00c1830f9240c6afcfe1a0d0611162c1bdf9b9fd6bbb3b3f` |
| Master revised `Code.gs` | `6d742f8fac4f9b98630f2afb44d4c2d7c7dc085a0c56c26391c6b921ee70db03` |
| Master helper | `58e8da3948f2890b42abd802485776169ff500dedcf060d27b449a60597bcb2c` |
| Master rollback | `c3ae9c480a97ad2771312f5f453adbe7049c07219f89624f75df543d319fa0a8` |

---

## 3. Decisions PDF

The R11 decisions PDF is:

```text
105 pages
searchable
unencrypted
Letter page size
SHA-256: 2ec123cd8fec2b35ad16da0c7e3cbc7a75f7c11d68aad6be4e2cce1247b73c1e
```

Independent comparison against the accepted 98-page R10 PDF found:

```text
first 98 pages: text-identical
first 98 pages: 98/98 rendered pages pixel-identical at 72 DPI
R11 appendix pages 99-105: visually inspected
clipping/overlap/blank-page defect: none observed
```

The PDF is visually sound. Its Phase 3 claims that the existing legacy outcome is mirrored as the same factual change and that recovery is status-first are not supported by the supplied executable source. The source defect, not PDF rendering, determines the NO-GO.

---

## 4. Current repository baseline

The package records backend base commit:

```text
ea2ad4c5b23cf72cff21ecebae5f0ee5d4c85115
```

At review time, the backend `test` head was:

```text
a5feb6408d44cf5b49ba10be0dfb0b6f616c4d66
fix(banking-pay): converge session after cancel resolution
```

That commit's direct parent is the package base and its change is Banking Pay-only. No later Candidate Daily source change was identified that repairs the R11 Availability adapter.

The frozen current backend contract still distinguishes terminal and non-terminal 409 outcomes for the legacy Availability command. In particular:

```text
COMMAND_IN_PROGRESS          -> STATUS_CHECK
SOURCE_IDENTITY_NOT_READY    -> STATUS_CHECK
IDENTITY_LINK_MISSING        -> STATUS_CHECK
IDENTITY_LINK_AMBIGUOUS      -> DO_NOT_RETRY
IDEMPOTENCY_KEY_REUSED       -> DO_NOT_RETRY
AVAILABILITY_VERSION_CONFLICT -> REFRESH
```

The Apps Script adapter must consume those exact `error_code` / `retry_class` facts. HTTP status alone is not sufficient authority.

---

## 5. Controlling accepted rules

The supplied accepted authorities establish all of the following:

1. The temporary legacy browser keeps its existing response contract, including mixed per-date outcomes.
2. A busy/update-window result is deferred and non-authoritative; it must not be treated as an accepted canonical change before the final accepted subset and durable receipt exist.
3. Phase 3 must submit the same factual dates/codes as the legacy outcome, not the original unfiltered request.
4. One request UUID, idempotency key, correlation ID, source HMAC and factual body must survive transport uncertainty.
5. A `STATUS_CHECK` result is not terminal. Status must be read before any exact retry, and the operation must remain recoverable.

Relevant package references include:

```text
accepted Phase 0 R5 00_HANDOVER.md:34-39
00_HANDOVER.md:43-47 and 108-118
02_CURRENT_STATE.md:47-54
decisions/CANDIDATE_DAILY_PHASE3_IMPLEMENTATION_AUTHORITY.md:53-68
decisions/CANDIDATE_DAILY_PHASE3_DECISION_COMPLIANCE_MATRIX.md:11-17
contracts/CANDIDATE_API_OPENAPI_V1_MERGED_R8.yaml:4390-4455
```

---

# 6. Bounded NO-GO finding family

## R11-AW-001 — Deferred rota-busy requests are mirrored before durable Google acceptance

### Source trace

The rota-busy branch in:

```text
source/availability-api/Code.gs:9296-9312
```

performs:

```text
_queueChanges(msisdn, changes)
_applyChangesToTilesCache(msisdn, changes)
construct results with applied:true, deferred:true
ctmsP3_mirrorLegacyAvailability_(...)
return the deferred legacy result
```

That branch does not write the Availability Sheet and does not call `_flushPendingWrites()`.

The eventual flush occurs separately in:

```text
source/availability-api/Code.gs:508-629
```

At flush time the legacy code re-evaluates:

```text
current 14-day window
candidate existence
Availability row existence
booked state
blocked state
allowed code
```

It can reject dates that the initial busy branch labelled `applied:true, deferred:true`. It also coalesces queued changes last-write-wins and clears the queue after the flush attempt.

### Reproduction

Independent probe `R11-AVAIL-003` proved:

```json
{
  "legacy_result": "applied:true, deferred:true, QUEUED_UNTIL_ROTA_IDLE",
  "mirror_called_before_return": true,
  "durable_sheet_write_in_branch": false,
  "flush_in_branch": false
}
```

### Consequence

CloudTMS can receive a canonical command for facts that Google has only queued and may later reject, supersede or fail to write. This directly contradicts the accepted rule that deferred busy-path facts are non-authoritative.

---

## R11-AW-002 — Normal mixed results forward legacy-rejected dates

### Source trace

The normal branch calculates an exact mixed result in:

```text
source/availability-api/Code.gs:9354-9374
```

Only accepted rows enter `setList`, and only that subset is written:

```text
source/availability-api/Code.gs:9376-9383
```

Only accepted rows update the existing cache:

```text
source/availability-api/Code.gs:9389-9391
```

However, the bridge call passes the original request as well as the result:

```text
source/availability-api/Code.gs:9393-9396
```

The helper receives `legacyResults` but ignores it:

```text
source/availability-api/CloudTMSCandidateBridge.gs:344-357
```

It normalizes every item in the original `changes` array and freezes that unfiltered body as the CloudTMS command.

### Reproduction

Independent probe `R11-AVAIL-001` supplied:

```text
2026-08-18 -> applied LD
2026-08-19 -> rejected BOOKED_LOCK
```

Observed CloudTMS body:

```json
[
  {"date":"2026-08-18","availability":"LD"},
  {"date":"2026-08-19","availability":"N"}
]
```

The rejected date was forwarded.

### Consequence

Depending on current CloudTMS state, either:

- CloudTMS accepts a date Google rejected, creating factual divergence; or
- the unfiltered command fails and the accepted Google dates are not mirrored.

Both outcomes violate the required same-factual-change boundary.

---

## R11-AW-003 — `STATUS_CHECK` 409 responses are deleted as terminal failures

### Source trace

The helper defines:

```javascript
function ctmsP3_stableFailure_(result) {
  return result && result.http_code >= 400 && result.http_code < 500
    && !result.not_found && !result.uncertain;
}
```

at:

```text
source/availability-api/CloudTMSCandidateBridge.gs:292-295
```

The initial execution path then clears the operation for any such result:

```text
source/availability-api/CloudTMSCandidateBridge.gs:364-380
```

The same broad classifier is used after the one exact retry:

```text
source/availability-api/CloudTMSCandidateBridge.gs:317-337
```

The frozen contract expressly defines non-terminal 409 responses carrying `retry_class: STATUS_CHECK`.

### Reproduction

Independent probe `R11-AVAIL-002` returned:

```json
{
  "error_code":"COMMAND_IN_PROGRESS",
  "retry_class":"STATUS_CHECK"
}
```

Observed behavior:

```json
{
  "operation_cleared":true,
  "status_probe_called":false
}
```

### Consequence

The adapter loses the request ID, key, correlation and exact body needed to discover the command's final state. A later invocation may create another operation or simply leave Google and CloudTMS un-reconciled. This is the opposite of status-first recovery.

---

# 7. Why the supplied green tests do not close the finding

The archive supplies raw TAP claiming:

```text
Focused Candidate Daily: 48 passed, 0 failed
Complete backend:         625 passed, 0 failed
```

The Phase 3 test was not directly runnable from the ZIP as delivered. It resolves source from:

```text
docs/candidate-app/phase3-apps-script/...
```

and resolves the HMAC vector from:

```text
tests/fixtures/candidate-daily-r5/canonicalization-v1-vectors.json
```

Neither dependency path is present in the original 46-entry archive. I reconstructed the expected repository layout from the byte-identical packaged source and the exact frozen vector, then reran the supplied Phase 3 test:

```text
12 passed
0 failed
```

That successful rerun still does not cover the blocker. The supplied uncertainty test covers network loss, status 404, one exact retry and later status success. It does not cover:

```text
mixed applied/rejected legacy results
busy/deferred non-authoritative results
409 COMMAND_IN_PROGRESS / STATUS_CHECK
409 SOURCE_IDENTITY_NOT_READY / STATUS_CHECK
409 IDENTITY_LINK_MISSING / STATUS_CHECK
malformed/non-contract 4xx response bodies
```

Independent bounded probes for the affected family passed 3/3 and reproduce all three defects.

I did not independently rerun the complete 625-test repository suite from the scoped ZIP because the archive is not the complete backend repository. The supplied TAP remains evidence of its originating run, not a substitute for the missing operation-level cases.

---

# 8. Required targeted correction

## 8.1 `source/availability-api/Code.gs`

### A. Rota-busy branch

In the branch at approximately `9296-9312`:

- preserve the existing browser response byte/shape contract;
- preserve `_queueChanges` and cache behavior;
- **remove the immediate CloudTMS mirror call** for `deferred:true` rows;
- do not create a bridge operation, make a request or log a bridge event for facts that remain only queued.

### B. `_flushPendingWrites()`

Amend only the existing flush owner at approximately `508-629` so it:

1. records the exact accepted `ymd` and normalized code per candidate after booked/block/window/code validation;
2. performs the existing value and background writes first;
3. adds a candidate to a local post-write mirror list only after its RangeList writes complete successfully;
4. releases the existing write lock before any network call;
5. invokes `ctmsP3_mirrorLegacyAvailability_` after the durable Google write using only the exact accepted subset;
6. makes no mirror call for rejected or failed dates;
7. leaves the existing browser deferred response, queue coalescing and legacy return shape unchanged.

The bridge operation identity is created immediately before that subset's first CloudTMS submission. It must then remain stable through recovery.

### C. Normal non-busy branch

At approximately `9393-9396`, pass the exact applied subset rather than the original request. The call should be based on:

```text
results where applied === true and deferred !== true
```

with date/code taken from the legacy result that corresponds to the actual Sheet write.

---

## 8.2 `source/availability-api/CloudTMSCandidateBridge.gs`

### A. `ctmsP3_mirrorLegacyAvailability_`

Change this function so that:

- `legacyResults` is the factual authority;
- original `changes` is not copied wholesale into the CloudTMS body;
- only rows with `applied === true` and `deferred !== true` are eligible;
- accepted date and code are validated against the existing closed legacy catalogue;
- no accepted rows means immediate no-op before identity lookup, Script Property mutation, logging or network;
- a malformed or contradictory legacy result fails open toward the existing legacy response and cannot invent a canonical command;
- the persisted fingerprint/body contains exactly the accepted subset.

### B. Replace `ctmsP3_stableFailure_`

Replace the HTTP-range classifier with an exact response disposition helper that reads the contract fields:

```text
json.error_code
json.retry_class
```

Required classes:

| Contract result | Local action |
|---|---|
| 2xx, `ok:true` | terminal success; clear |
| `DO_NOT_RETRY` | terminal rejection; bounded log; clear |
| `REFRESH` | stable conflict; bounded log; clear only as an explicit terminal rejection |
| `STATUS_CHECK` | persist `recovery_only`; call status; do not clear |
| `RETRY_SAME_KEY` | preserve exact operation; follow only the frozen exact-retry rule |
| `RETRY_AFTER` or uncertain transport | persist; status-first |
| malformed 4xx without a valid closed error/retry pair | preserve as uncertain; do not clear |
| authoritative status 404 and retry not consumed | one exact retry |
| authoritative status 404 after retry consumed | status-only; no second retry |

### C. `ctmsP3_recoverLegacyAvailability_`

Use the same exact classifier after status and after the single retry. In particular:

- `STATUS_CHECK` must retain the operation;
- terminal status body states `COMPLETED` and `FAILED_FINAL` may clear;
- the first authoritative `NOT_FOUND` may set `retry_consumed=true` and execute the identical request once;
- no code path may create a replacement request UUID, idempotency key, correlation ID, source HMAC or body because the outcome is uncertain.

---

## 8.3 Tests

Extend `tests/candidate-daily-phase3-apps-script.test.js` with direct executable cases for:

1. all accepted rows;
2. all rejected rows — zero CloudTMS request/state/log;
3. mixed accepted/booked/blocked/outside-window/validation rows — body equals accepted subset only;
4. busy/deferred response — zero CloudTMS request until flush;
5. flush-time mixed result — only successfully written rows mirrored;
6. `COMMAND_IN_PROGRESS / STATUS_CHECK` — operation retained and status invoked;
7. `SOURCE_IDENTITY_NOT_READY / STATUS_CHECK` — operation retained;
8. `IDENTITY_LINK_MISSING / STATUS_CHECK` — operation retained;
9. `AVAILABILITY_VERSION_CONFLICT / REFRESH` — explicit terminal conflict handling;
10. `IDEMPOTENCY_KEY_REUSED / DO_NOT_RETRY` — terminal rejection handling;
11. malformed 409 body — operation retained, no replacement identity;
12. exact lost-response sequence with no second exact retry.

Every replay test must compare the complete body, request UUID, idempotency key, correlation ID and source HMAC, not merely request count.

---

## 8.4 Documentation and pack construction

Update:

```text
00_HANDOVER.md
02_CURRENT_STATE.md
03_VERIFICATION_SUMMARY.md
decisions/CANDIDATE_DAILY_PHASE3_IMPLEMENTATION_AUTHORITY.md
decisions/CANDIDATE_DAILY_PHASE3_DECISION_COMPLIANCE_MATRIX.md
current Decisions PDF
```

The next archive must also make its supplied Phase 3 test self-contained by including its expected source layout and frozen HMAC fixture, or by changing the test to resolve the packaged `source/...` paths.

Regenerate both manifests and the validator. The validator should verify all runtime dependencies of the supplied test, not only the test file itself.

---

# 9. Explicit no-change boundary

The bounded R12 correction authorized by this handover requires no change to:

```text
Supabase schema or data
Phase 2 RPC signatures or definitions
Phase 1B Worker routes or signing protocol
Candidate frontend or Candidate Office
Master Rota helper/source
projection adapter
effect primitives or Emergency providers
legacy browser UI, login or msisdn flow
manifest, OAuth scopes or triggers
rates, pay, charge, VAT, ERNI, margin or TSFIN
Invoice, payment, Banking Pay or Policy X
production
```

No broad rewrite is justified. The correction belongs to the existing Availability queue/write seam, the existing Availability bridge helper and their focused tests/documents.

---

# 10. Required R12 re-review gates

A corrected package is eligible for re-review only when all of the following are present:

1. exact revised and rollback source hashes;
2. self-contained runnable Phase 3 tests;
3. direct proof that deferred rows cause no CloudTMS command before flush;
4. direct proof that mixed legacy results submit only the durable accepted subset;
5. direct proof that every `STATUS_CHECK` result preserves the exact operation and enters status recovery;
6. direct proof of one exact retry only after authoritative not-found;
7. retained missing/false flag hard no-op;
8. focused and complete repository regression evidence;
9. regenerated Decisions PDF, manifests and validator;
10. a fresh end-to-end independent review of the complete R12 source, including operation families not certified by this stop-rule NO-GO.

Only after source acceptance may the separate manual Google installation/proving runbook begin with the bridge flag false.

---

# 11. Review execution and limitations

Performed:

```text
archive integrity and manifest verification
validator rerun
source hash verification
R10/R11 PDF text and rendered-page comparison
full Availability write-path source trace
current Git backend head/source-contract inspection
reconstructed supplied Phase 3 test rerun: 12/12
independent Availability-family probes: 3/3
```

Not performed:

```text
live Google source export or project inspection
Apps Script paste/save/version/deployment
Google trigger or Sheet mutation
signed Apps Script-to-Worker execution
Candidate feature or entitlement enablement
business RPC execution
provider or Emergency effect
production action
```

A fresh read-only Supabase snapshot was attempted, but the connector became unavailable during this R11 review. The source NO-GO does not depend on a database-state assumption, and no database mutation was attempted.

---

# 12. Final disposition

> **NO-GO for Phase 3 source installation/proving gate.**

The R11 Availability adapter does not mirror the same durable factual legacy outcome and does not preserve status-first recovery for non-terminal 409 responses.

The next handover must be a tightly targeted Availability write/mirror/recovery correction. It must not use this finding as authority for a broad Candidate Daily, Google, Worker, database or financial rewrite.
